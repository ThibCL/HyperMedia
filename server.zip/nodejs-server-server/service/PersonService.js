'use strict';


/**
 * returns the list of all persons
 *
 * returns List
 **/
exports.getAllPersons = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "description" : "One of our most dedicated member. Joined in 2018 and is now responsible for the event organisation.",
  "photo" : [ "michael-jordan", "micheal-at-his-first-event" ],
  "person-id" : 3,
  "first-name" : "Micheal",
  "last-name" : "jordan"
}, {
  "description" : "One of our most dedicated member. Joined in 2018 and is now responsible for the event organisation.",
  "photo" : [ "michael-jordan", "micheal-at-his-first-event" ],
  "person-id" : 3,
  "first-name" : "Micheal",
  "last-name" : "jordan"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * return the person that corresponds to the id
 *
 * personId Long 
 * returns Person
 **/
exports.getPersonByID = function(personId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "description" : "One of our most dedicated member. Joined in 2018 and is now responsible for the event organisation.",
  "photo" : [ "michael-jordan", "micheal-at-his-first-event" ],
  "person-id" : 3,
  "first-name" : "Micheal",
  "last-name" : "jordan"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns the contact person of the specified event
 *
 * eventId Long 
 * returns Person
 **/
exports.getPersonContact = function(eventId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "description" : "One of our most dedicated member. Joined in 2018 and is now responsible for the event organisation.",
  "photo" : [ "michael-jordan", "micheal-at-his-first-event" ],
  "person-id" : 3,
  "first-name" : "Micheal",
  "last-name" : "jordan"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Return the person involved in the service specified
 *
 * serviceId Long 
 * returns List
 **/
exports.getPersonInvolvedIn = function(serviceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "description" : "One of our most dedicated member. Joined in 2018 and is now responsible for the event organisation.",
  "photo" : [ "michael-jordan", "micheal-at-his-first-event" ],
  "person-id" : 3,
  "first-name" : "Micheal",
  "last-name" : "jordan"
}, {
  "description" : "One of our most dedicated member. Joined in 2018 and is now responsible for the event organisation.",
  "photo" : [ "michael-jordan", "micheal-at-his-first-event" ],
  "person-id" : 3,
  "first-name" : "Micheal",
  "last-name" : "jordan"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

